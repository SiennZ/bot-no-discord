const Discord = require("discord.js");
const  client = new Discord.Client();
const config  = require("./config.json")

client.on("ready", () => {
    console.log(`Bot foi iniciado, com ${client.users.size} usuários, em ${client.channels.size} canais, em ${client.guilds.size} servidores.`); 
    client.user.setActivity(`Pronto para brincar!`);
  });
  
  client.on("message", async message => {
  
      if(message.author.bot) return;
      if(message.channel.type === "dm") return;
      if(!message.content.startsWith(config.prefix)) return;
  
    const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
    const comando = args.shift().toLowerCase();
    
    // comando ping
    if(comando === "ping") {
      const m = await message.channel.send("Ping?");
      m.edit(`TAKA A MAE PRA VER SE KICKA! A Latência é ${m.createdTimestamp - message.createdTimestamp}ms.`);
    }
    
  });
  client.on('message', message => {
  // Ignore messages that aren't from a guild
  if (!message.guild) return;
   // If the message content starts with "!kick"
   if (message.content.startsWith ('!kick')) {
    // Assuming we mention someone in the message, this will return the user
    // Read more about mentions over at https://discord.js.org/#/docs/main/master/class/MessageMentions
    const user = message.mentions.users.first();
    // If we have a user mentioned
    if (user) {
      // Now we get the member from the user
      const member = message.guild.member(user);
      // If the member is in the guild
      if (member) {
        /**
         * Kick the member
         * Make sure you run this on a member, not a user!
         * There are big differences between a user and a member
         */
        member
          .kick('Optional reason that will display in the audit logs')
          .then(() => {
            // We let the message author know we were able to kick the person
            message.reply(`Mae Kickada com sucesso! ${user.tag}`);
          })
          .catch(err => {
            // An error happened
            // This is generally due to the bot not being able to kick the member,
            // either due to missing permissions or role hierarchy
            message.reply('Nao consegui kicka-lo por motivos _ocultos_...');
            // Log the error
            console.error(err);
          });
      } else {
        // The mentioned user isn't in this guild
        message.reply("Esse usuario nao pertence aos _meus_ umbrais!");
      }
      // Otherwise, if no user was mentioned
    } else {
      message.reply("Você não escolheu quem deseja Kickar igual sua mae!");
    }
  }
});
// Create an event listener for messages
    client.on('message', message => {
    // If the message is "what is my avatar"
    if (message.content === 'minha foto gay') {
      // Send the user's avatar URL
      message.reply(message.author.displayAvatarURL());

    }
});
    client.on('message', message => {
    // If the message is '!rip'
    if (message.content === '!rip') {
      // Create the attachment using MessageAttachment
      const attachment = new Discord.MessageAttachment('https://i.imgur.com/w3duR07.png');
      // Send the attachment in the message channel
      message.channel.send(attachment);
    }
});
  client.login(config.token);